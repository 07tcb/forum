from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
import os
import time
import base64
import rsa
from werkzeug.security import generate_password_hash, check_password_hash

DB_NAME = "forum_stage3.db"
KEYS_DIR = "keys"
PRIVATE_KEY_FILE = os.path.join(KEYS_DIR, "private.pem")
PUBLIC_KEY_FILE = os.path.join(KEYS_DIR, "public.pem")

app = Flask(__name__)
app.secret_key = "byt-den-har-nyckeln-igen-igen"

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_keys():
    os.makedirs(KEYS_DIR, exist_ok=True)
    if not (os.path.exists(PRIVATE_KEY_FILE) and os.path.exists(PUBLIC_KEY_FILE)):
        pub, priv = rsa.newkeys(2048)
        with open(PRIVATE_KEY_FILE, "wb") as f:
            f.write(priv.save_pkcs1())
        with open(PUBLIC_KEY_FILE, "wb") as f:
            f.write(pub.save_pkcs1())
    with open(PRIVATE_KEY_FILE, "rb") as f:
        priv = rsa.PrivateKey.load_pkcs1(f.read())
    with open(PUBLIC_KEY_FILE, "rb") as f:
        pub = rsa.PublicKey.load_pkcs1(f.read())
    return priv, pub

PRIVATE_KEY, PUBLIC_KEY = init_keys()

def sign_login_token(user_id: int) -> None:
    token_data = f"{user_id}|{int(time.time())}"
    signature = rsa.sign(token_data.encode("utf-8"), PRIVATE_KEY, "SHA-256")
    session["token_data"] = token_data
    session["rsa_sig"] = base64.b64encode(signature).decode("ascii")

def verify_login_token():
    token_data = session.get("token_data")
    sig_b64 = session.get("rsa_sig")
    if not token_data or not sig_b64:
        return None
    try:
        signature = base64.b64decode(sig_b64.encode("ascii"))
        rsa.verify(token_data.encode("utf-8"), signature, PUBLIC_KEY)
        user_id = int(token_data.split("|")[0])
    except Exception:
        session.clear()
        return None
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, username, display_name FROM users WHERE id = ?", (user_id,))
    user = cur.fetchone()
    conn.close()
    if not user:
        session.clear()
        return None
    return user

def get_current_user():
    return verify_login_token()

@app.context_processor
def inject_user():
    return {"current_user": get_current_user()}

@app.route("/")
def index():
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT topics.id,
               topics.title,
               topics.created_at,
               u.username,
               u.display_name,
               COUNT(p.id) AS post_count
        FROM topics
        JOIN users u ON topics.user_id = u.id
        LEFT JOIN posts p ON p.topic_id = topics.id
        GROUP BY topics.id
        ORDER BY topics.created_at DESC
        """
    )
    topics = cur.fetchall()
    conn.close()
    return render_template("index.html", topics=topics)

@app.route("/topic/<int:topic_id>")
def topic_view(topic_id):
    user = get_current_user()
    user_id = user["id"] if user else None

    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT topics.id,
               topics.title,
               topics.created_at,
               u.username,
               u.display_name
        FROM topics
        JOIN users u ON topics.user_id = u.id
        WHERE topics.id = ?
        """,
        (topic_id,),
    )
    topic = cur.fetchone()
    if not topic:
        conn.close()
        return "Topic hittades inte", 404

    cur.execute(
        """
        SELECT p.id,
               p.content,
               p.created_at,
               u.username,
               u.display_name,
               IFNULL(lc.like_count, 0) AS like_count,
               CASE WHEN ? IS NOT NULL AND EXISTS(
                    SELECT 1 FROM likes WHERE likes.post_id = p.id AND likes.user_id = ?
               ) THEN 1 ELSE 0 END AS liked_by_me
        FROM posts p
        JOIN users u ON p.user_id = u.id
        LEFT JOIN (
            SELECT post_id, COUNT(*) AS like_count
            FROM likes
            GROUP BY post_id
        ) lc ON lc.post_id = p.id
        WHERE p.topic_id = ?
        ORDER BY p.created_at ASC
        """,
        (user_id, user_id, topic_id),
    )
    posts = cur.fetchall()
    conn.close()
    return render_template("topic.html", topic=topic, posts=posts)

@app.route("/topic/new", methods=["GET", "POST"])
def new_topic():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))
    error = None
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        content = request.form.get("content", "").strip()
        if not title or not content:
            error = "Rubrik och första inlägget får inte vara tomma."
        else:
            conn = get_db()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO topics (title, user_id) VALUES (?, ?)",
                (title, user["id"]),
            )
            topic_id = cur.lastrowid
            cur.execute(
                "INSERT INTO posts (topic_id, user_id, content) VALUES (?, ?, ?)",
                (topic_id, user["id"], content),
            )
            conn.commit()
            conn.close()
            return redirect(url_for("topic_view", topic_id=topic_id))
    return render_template("new_topic.html", error=error)

@app.route("/topic/<int:topic_id>/reply", methods=["POST"])
def reply_topic(topic_id):
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))
    content = request.form.get("content", "").strip()
    if content:
        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO posts (topic_id, user_id, content) VALUES (?, ?, ?)",
            (topic_id, user["id"], content),
        )
        conn.commit()
        conn.close()
    return redirect(url_for("topic_view", topic_id=topic_id))

@app.route("/register", methods=["GET", "POST"])
def register():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        display_name = request.form.get("display_name", "").strip()
        if not username or not password or not display_name:
            error = "Alla fält måste fyllas i."
        else:
            try:
                password_hash = generate_password_hash(password)
                conn = get_db()
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO users (username, password_hash, display_name) VALUES (?, ?, ?)",
                    (username, password_hash, display_name),
                )
                conn.commit()
                conn.close()
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                error = "Användarnamnet är upptaget."
    return render_template("register.html", error=error)

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            "SELECT id, username, password_hash, display_name FROM users WHERE username = ?",
            (username,),
        )
        user = cur.fetchone()
        conn.close()
        if not user or not check_password_hash(user["password_hash"], password):
            error = "Fel användarnamn eller lösenord."
        else:
            sign_login_token(user["id"])
            return redirect(url_for("index"))
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/like/<int:post_id>", methods=["POST"])
def like_post(post_id):
    user = get_current_user()
    if not user:
        return jsonify({"error": "not_authenticated"}), 401

    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT 1 FROM posts WHERE id = ?", (post_id,))
    if not cur.fetchone():
        conn.close()
        return jsonify({"error": "no_such_post"}), 404

    cur.execute(
        "SELECT id FROM likes WHERE post_id = ? AND user_id = ?",
        (post_id, user["id"]),
    )
    existing = cur.fetchone()

    if existing:
        cur.execute("DELETE FROM likes WHERE id = ?", (existing["id"],))
        liked = False
    else:
        cur.execute(
            "INSERT INTO likes (post_id, user_id) VALUES (?, ?)",
            (post_id, user["id"]),
        )
        liked = True

    cur.execute("SELECT COUNT(*) AS c FROM likes WHERE post_id = ?", (post_id,))
    like_count = cur.fetchone()["c"]

    conn.commit()
    conn.close()

    return jsonify({"liked": liked, "like_count": like_count})

if __name__ == "__main__":
    if not os.path.exists(DB_NAME):
        print("Skapa databasen först med schema_stage3.sql")
    app.run(debug=True)
