from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "byt-den-har-nyckeln-igen"
DB_NAME = "forum_stage2.db"

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def get_current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, username, display_name FROM users WHERE id = ?", (user_id,))
    user = cur.fetchone()
    conn.close()
    return user

@app.context_processor
def inject_user():
    return {"current_user": get_current_user()}

@app.route("/")
def index():
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT topics.id, topics.title, topics.created_at,
               users.username, users.display_name,
               COUNT(posts.id) AS post_count
        FROM topics
        JOIN users ON topics.user_id = users.id
        LEFT JOIN posts ON posts.topic_id = topics.id
        GROUP BY topics.id
        ORDER BY topics.created_at DESC
        """
    )
    topics = cur.fetchall()
    conn.close()
    return render_template("index.html", topics=topics)

@app.route("/topic/<int:topic_id>")
def topic_view(topic_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT topics.id, topics.title, topics.created_at,
               users.username, users.display_name
        FROM topics
        JOIN users ON topics.user_id = users.id
        WHERE topics.id = ?
        """,
        (topic_id,),
    )
    topic = cur.fetchone()
    if not topic:
        conn.close()
        return "Topic hittades inte", 404

    cur.execute(
        """
        SELECT posts.id, posts.content, posts.created_at,
               users.username, users.display_name
        FROM posts
        JOIN users ON posts.user_id = users.id
        WHERE posts.topic_id = ?
        ORDER BY posts.created_at ASC
        """,
        (topic_id,),
    )
    posts = cur.fetchall()
    conn.close()
    return render_template("topic.html", topic=topic, posts=posts)

@app.route("/topic/new", methods=["GET", "POST"])
def new_topic():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))
    error = None
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        content = request.form.get("content", "").strip()
        if not title or not content:
            error = "Rubrik och första inlägget måste fyllas i."
        else:
            conn = get_db()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO topics (title, user_id) VALUES (?, ?)",
                (title, user["id"]),
            )
            topic_id = cur.lastrowid
            cur.execute(
                "INSERT INTO posts (topic_id, user_id, content) VALUES (?, ?, ?)",
                (topic_id, user["id"], content),
            )
            conn.commit()
            conn.close()
            return redirect(url_for("topic_view", topic_id=topic_id))
    return render_template("new_topic.html", error=error)

@app.route("/topic/<int:topic_id>/reply", methods=["POST"])
def reply_topic(topic_id):
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))
    content = request.form.get("content", "").strip()
    if content:
        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO posts (topic_id, user_id, content) VALUES (?, ?, ?)",
            (topic_id, user["id"], content),
        )
        conn.commit()
        conn.close()
    return redirect(url_for("topic_view", topic_id=topic_id))

@app.route("/register", methods=["GET", "POST"])
def register():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        display_name = request.form.get("display_name", "").strip()
        if not username or not password or not display_name:
            error = "Alla fält måste fyllas i."
        else:
            try:
                password_hash = generate_password_hash(password)
                conn = get_db()
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO users (username, password_hash, display_name) VALUES (?, ?, ?)",
                    (username, password_hash, display_name),
                )
                conn.commit()
                conn.close()
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                error = "Användarnamnet är upptaget."
    return render_template("register.html", error=error)

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        conn = get_db()
        cur = conn.cursor()
        cur.execute(
            "SELECT id, username, password_hash, display_name FROM users WHERE username = ?",
            (username,),
        )
        user = cur.fetchone()
        conn.close()
        if not user or not check_password_hash(user["password_hash"], password):
            error = "Fel användarnamn eller lösenord."
        else:
            session["user_id"] = user["id"]
            return redirect(url_for("index"))
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

if __name__ == "__main__":
    if not os.path.exists(DB_NAME):
        print("Skapa databasen först med schema_stage2.sql")
    app.run(debug=True)
